-COMP 5421: Advanced Programming, Assignment 4
-Name: Yun Ni, 40179775
-No special Instructions
-No extra features
-No known bugs to report 
-I am using CLion as IDE, so there is an CMakeLists in the zip file. 




This program is implementing a Shape dimension graph that uses the Shape inheritance hierarchy.

The purpose of this program is to implement the following in C++:

1) Fundamental object-oriented programming concepts (inheritance and polymorphism)

2) Overriding, virtual functions and dynamic blinding polymorphism

3) Two-dimensional arrays using vector, container class templates in the C++ Standard Template Library (STL) 

4) Smart pointers  